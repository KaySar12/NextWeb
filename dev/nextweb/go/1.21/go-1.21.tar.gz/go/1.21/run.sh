#!/bin/bash

source /.env
eval $EXEC_SCRIPT


