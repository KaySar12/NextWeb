#!/bin/bash

chown -R 5050:5050 data
