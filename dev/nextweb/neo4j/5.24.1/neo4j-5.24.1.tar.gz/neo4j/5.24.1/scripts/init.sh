#!/bin/bash

chown -R 7474:7474 data