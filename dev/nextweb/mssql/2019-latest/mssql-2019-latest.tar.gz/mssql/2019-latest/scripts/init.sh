#!/bin/bash

chown -R 10001:10001 data